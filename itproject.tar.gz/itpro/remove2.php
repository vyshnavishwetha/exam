<?php
include('connect.php');
if(isset($_GET['remove_number']))
{
	$res=mysqli_query($con,"SELECT userfile FROM uploads WHERE number=".$_GET['remove_number']);
	$row=mysqli_fetch_array($res);
	mysqli_query($con,"DELETE FROM uploads WHERE number=".$_GET['remove_number']);
	unlink("uploads/".$row['userfile']);
	header("Location: cse3.php");
	echo "deleted sucessfully";
}
?>
