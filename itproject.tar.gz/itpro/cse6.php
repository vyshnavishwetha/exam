<?php
session_start();
?>
<!DOCTYPE html>
<html >

<head>
  
<meta charset="UTF-8">
 

  
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  

      <style>
      
  @import url(https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700);


body {
  background: #999;

  padding: 40px;
 
 font-family: "Open Sans Condensed", sans-serif;
}


#bg {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;

  background: url() center center no-repeat;
 
 background-size: cover;
 
 -webkit-filter: blur(5px);    
}


form {
  position: relative;
  width:;
  margin: 0 auto;
  background: rgba(130,130,130,.3);
  padding: 20px 22px;
  border: 1px solid;
  border-top-color: rgba(255,255,255,.4);
  border-left-color: rgba(255,255,255,.4);
  border-bottom-color: rgba(60,60,60,.4);
  border-right-color: rgba(60,60,60,.4);
}


form input, form button {
  width: 212px;
  border: 1px solid;
  border-bottom-color: rgba(255,255,255,.5);
  border-right-color: rgba(60,60,60,.35);
  border-top-color: rgba(60,60,60,.35);
  border-left-color: rgba(80,80,80,.45);
  background-color: rgba(0,0,0,.2);
  background-repeat: no-repeat;
  padding: 8px 24px 8px 10px;
  font: bold .875em/1.25em "Open Sans Condensed", sans-serif;
  letter-spacing: .075em;
  color: #fff;
  text-shadow: 0 1px 0 rgba(0,0,0,.1);
  margin-bottom: 19px;
}
table{
 width:100%;

  border-collapse:collapse;
 background-color:white;
   }
   td,th{
  border:1px solid;
  text-align:center;
  }
body{
background-image: url("bg3.jpg");
    background-repeat: no-repeat;
 background-size: 1400px 700px;
margin:0;
}

</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>


</head>


<body>
<div id="bg"></div>

<form method="post" action="up5.php" enctype="multipart/form-data">
<a href="home1.php">Logout</a></td> 

<table width="750" border="0" cellspacing="1" cellpadding="1">

<tbody>

<tr>

<td width="246">

<input type="hidden" name="MAX_FILE_SIZE" value="2000000" />

 

<input id="userfile" type="file" name="userfile" /></td>

<td width="80"><input id="upload" type="submit" name="upload" value="upload" /></td>

</tr>

</tbody>

</table>
</form>

<form action="remove5.php" method="GET">
        
 <?php
 include "connect.php";
$sql="SELECT * FROM upload5";
 $result=mysqli_query($con,$sql) or die('sorry');
 
?>

</div><br><br>
	<div id=tables class="table">
		<table>
		<tr>	<th>sl.no</th>
			<th>File Name</th>
			<th>Files</th>
		</tr>	
		<?php while($row = mysqli_fetch_array($result)){?>
		<tr>	<?php $_SESSION['filename']=$row['userfile']; ?>
			<td> <?php echo $row['number'] ?> </td>
			<td> <?php echo $row['userfile'] ?></td>
			
			<td> <a href="remove5.php?remove_number=<?php echo $row['number'] ?>">DELETE</a> </td>
			
		</tr>
		<?php } ?>
		</table>
		
	</div>
	<br><br>
	
		
</form>
<div id="footer">
</div>



  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'>
</script>


  
</body>

</html>
