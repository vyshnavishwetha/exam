<?php
$username = $_POST['uname'];
$password = $_POST['psw'];
$con=mysqli_connect("localhost","root","123456","itpro") or die("error connecting to database");
echo $username;
echo $password;

$qz = "SELECT * FROM login where username='$username' and password='$password' ";

$result=mysqli_query($con,$qz)or die("error querying database");
$row=mysqli_fetch_array($result);
$usertype=$row['usertype'];
if ($row>0) 
{
if($usertype=='1')
{
header("location:semester.html");
}
else
{
header("location:studentsemester.html");
}
}
else

{
header('Location: home1.php?error=invalid_creds');
}
?>
