<?php
include_once 'connect.php';
$query = "select *from upload1 order by number";
$result = mysqli_query($con,$query);
?>
<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="style.css" type="text/css" />
<meta charset="UTF-8">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  

      <style>
      
  @import url(https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700);


body {
  background: #999;

  padding: 40px;
 
 font-family: "Open Sans Condensed", sans-serif;
}


#bg {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;

  background: url(press.jpg) no-repeat center center fixed;
 
 background-size: cover;
 
 -webkit-filter: blur(5px);    
}


form {
  position: absolute;
  width: ;
  margin: 0 auto;
  background: rgba(130,130,130,.3);
  padding: 20px 22px;
  border: 1px solid;
  border-top-color: rgba(255,255,255,.4);
  border-left-color: rgba(255,255,255,.4);
  border-bottom-color: rgba(60,60,60,.4);
  border-right-color: rgba(60,60,60,.4);
}


form input, form button {
  width: absolute;
  border: 1px solid;
  border-bottom-color: rgba(255,255,255,.5);
  border-right-color: rgba(60,60,60,.35);
  border-top-color: rgba(60,60,60,.35);
  border-left-color: rgba(80,80,80,.45);
  background-color: rgba(0,0,0,.2);
  background-repeat: no-repeat;
  padding: inherit;
  font: bold .875em/1.25em "Open Sans Condensed", sans-serif;
  letter-spacing: .075em;
  color: #fff;
  text-shadow: 0 1px 0 rgba(0,0,0,.1);
  margin-bottom: 19px;
}
table{
 width:100%;

  border-collapse:collapse;
 background-color:white;
   }
   td,th{
  border:1px solid;
  text-align:center;
  }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>
<body>
</br>
</br>
</div>
	<div id=tables class="table">
<right><a href="home1.php"><button>LOG-OUT</button></a></right>
		<table>
		<tr>	<th>sl.no</th>
			<th>File Name</th>
			<th>Files</th>
		</tr>	
		<?php while($row = mysqli_fetch_array($result)){?>
		<tr>	
			<td> <?php echo $row['number'] ?> </td>
			<td> <?php echo $row['userfile'] ?></td>
			<td> <a href="upload1/<?php echo $row['userfile'] ?>">open</a> </td>
		</tr>
		<?php } ?>
		</table>
	</div>	

<div id="footer">
</div>
</body>
</html>
