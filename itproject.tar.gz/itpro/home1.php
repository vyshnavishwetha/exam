<html>
<head>
<title> Presidency University </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body {font-family: Arial, Helvetica, sans-serif;}
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #FF5733;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
	float: right;
}
button {
    background-color:orange;
    color: white;
    padding: 14px 16px;
    margin: 3px 0;
    border: none;
    cursor: pointer;
    width: 100%;
	float: top;
}

button:hover {
    opacity: 0.8;
}
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 20%;
    border-radius: 40%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
<style>
body

{

background-image: url("p1.jpg");
background-repeat:no-repeat;
 background-size: 1400px 700px;
margin:0;
}
.box
{
    background-color:Dodgerblue;
    width: 300px;
    padding: 25px;
    margin: 50px;
}
.topnav {
    background-color: #115ed5;
   overflow: hidden; 
    margin:0;
}
.topnav a {
    float: right;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 40px;
    text-decoration: none;
    font-size: 17px;
}
.topnav a:hover {
    background-color: #ddd;
    color: black;
}
.topnav a.active {
    background-color: #4CAF50;
    color: white;
}


.topnav input[type=text] {
 
 padding: 6px;
  margin-top: 8px;
 
 font-size: 17px;
  border: none;

}




.topnav form.example input[type=text] {
  
padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

/* Style the submit button */
form.example button {
  float: none;
  width: auto;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 15px;
  border: 1px solid grey;
  border-left: none; /* Prevent double borders */
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

/* Clear floats */
form.example::after {
  content: "";
  clear: both;
  display: table;
}

@media screen and (max-width: 600px) {
 
 .topnav .search-container {
    
float: none;
 
 }
.topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 10%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}

.col-container {
    display: table;
    width: 100%;
}
.col {
    display: table-cell;
    padding: 10px;
	text-align:justify;
}
.footer-container {
  position : relative;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1px 10px;
  background-color:#0000ff;
  color: white;
  text-align: center;

</style>
</head>
<body style="background-color:black;">
<h3><img src="p2.jpg" height="18%" width="40%"/> &nbsp</font></i></h3>
<div class="topnav">
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" align="right" >Login</button>

<a href="#About us">About us</a>

</div>

<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


<div id="id01" class="modal">
	
  
  <form class="modal-content animate" method="post" action="login.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="avatar.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
        
      <button type="submit">Login</button>
<?php
if (isset($_GET['error']) && $_GET['error'] == 'invalid_creds'){
	echo'<p style="color: red">You have entered an invalid username or password.</p>';
}
?>
	  </form>
<br><br><br><br><br>
<a href="facultyregistration.html"><button>Faculty registration</button></a>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      
      <span class="psw"> <a href="#"></a></span>
    </div>

</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<div class="col-container">
  <div class="col" style="background:black">
    <h3> <font color="white"> Presidency University </font> </h3>
<p> <font color="white">
<h>PRESIDENCY UNIVERSITY</h>

Presidency University is a private university approved by the Government of Karnataka in 2013. Built on a sprawling campus of 60 plus acres with a salubrious ambience, the University has excellent infrastructure and outstanding academic fraternity drawn from reputed institutions like the Ills, BITS, NITs, IIMs and other premier institutions across the country. Committed to quality and academic excellence, the University has redefined the learning process by adopting unique pedagogy which is built on an academic content that is global and contemporary as well. The campus is vibrant with co-curricular and extracurricular activities, workshops and other initiatives that provide a commendable value addition to the Engineering, Management and Law programmes.
  </div>
  <div class="col" style="background:black">
    <h3> <font color="white"> Lab </font> </h3>
 <img src="presidency-university-bangalore-lab-1.jpg" height="300" width="300" />
  </div>
  <div class="col" style="background:black">
    <h3> <font color="white"> Campus </font> </h3>
     <img src="PUD1.jpg" height="300" width="300" />
  </div>
  <div class="col" style="background:black">
    <h3> <font color="white"> Library </font></h3>
 <img src="883A3034.jpg" height="300" width="300" />
  </div>
</div>
<div class="footer-container">
<h4> AllRightsReserved@PresidencyUniverity2018 </h4>
</div>
</body>

</html>
