<?php  
include 'connect.php';
   $qz = "SELECT * FROM login";

$result=mysqli_query($con,$qz)or die("error querying database");
while($row=mysqli_fetch_array($result))
{
$to_email = $row['username'];
$subject = 'New ppts notification';
$message = 'The ppts have been uploaded. Please check website and download ppts';
$headers = 'From:presidencyppts.com';
mail($to_email,$subject,$message,$headers);
}
?>
