<?php
$name=$_POST['faculty_name'];
$subject=$_POST['subject'];
$semester=$_POST['semester'];
$email=$_POST['email'];
$mobile=$_POST['contact_no'];
$username=$_POST['username'];
$password=$_POST['psw'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysqli_connect("localhost", "root", "123456","itpro") or die("cannot connect to database");


// SQL query to fetch information of registerd users and finds user match.
$query ="insert into facultyreg(faculty_name,subject,semester,e_mail,contact_no,user_name,password)values('$name','$subject','$semester','$email','$mobile','$username','$password')" or die("error querying database".mysqli_error($connection));
$query1 ="insert into login(username,password,usertype)values('$username','$password',1)" or die("error querying database");
$result=mysqli_query($connection,$query);
$result1=mysqli_query($connection,$query1);
 if($result1==TRUE)
{
header("location:home1.php");
}
else
{
$er=mysqli_error($connection);
echo $er;
}
// Closing Connection


?>
