<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  

  text-align:center;

}
 div.container {
 border:1px solid black;
    width:30%; 
    margin:1%;
    position: fixed;
    top: 30%;
    left: 35%;
  }

.topnav {
  overflow: hidden;
  background-color: #F00000;
   position: fixed;
    top: 10%;
    width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
}

.topnav .search-container {
  position:absolute;
    left:20%;
    top:5%;
    width:auto;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
<script>
function validate(){  
var name=document.myform.name.value;  
var password=document.myform.password.value;  
  
if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
else if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }  
var x=document.myform.email.value;  
var atposition=x.indexOf("@");  
var dotposition=x.lastIndexOf(".");  
if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  }  
var num=document.myform.num.value;  
if (isNaN(num)){  
  document.getElementById("numloc").innerHTML="Enter Numeric value only";  
  return false;  
}else if(num.length!=10){  alert("Invalid mobile number");  
  return false;  
  }
  else{
  return true;  
  }  
}  
</script>
</head>
<body>

<a href="login.php"><button style="float:right;">LOGIN</button></a>
 <select class="dropdown" style="float:right;" onchange="location=this.value;">
         <option value="" selected="selected" selected hidden>REGISTER</option>
    
</select> 
<div class="topnav">
  <a class="" href="reg.html">Home</a>
  <a href="#about">About</a>
  <a href="#contact">Contact</a>
  <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>
<div class="container">
<p><span class="error">CUSTOMER REGISTER</span></p>
<p><span class="error">*required field.</span></p>
<form name="myform" method="post" action="creg1.php" onsubmit="return validate()">
Faculty Name: <input type="text" name="name" required>
  <span class="error">* </span>
 </br> 
 </br>
Name: <input type="text" name="name" required>
  <span class="error">* </span>
 </br> 
 </br>
  E-mail: <input type="text" name="email" required>
  <span class="error">* </span>
 </br> 
  </br>
   Mobile: <input type="text" name="num"  required><span id="numloc" class="error">*</span>

 </br> 
  </br>
   Password: <input type="password" name="password" required>
  <span class="error">* </span>
 </br> 
  </br>
  <input type="checkbox" name="notify" value="notify">Send regular updates and offers
  </br>
  </br>
  <input type="submit" name="submit" value="Submit">  
  </br>
</form>

</div>
</body>
</html>
