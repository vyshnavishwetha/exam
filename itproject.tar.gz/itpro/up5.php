<?php
include 'connect.php';
$msg="";

if(isset($_POST['upload'])){
  $target="upload5/".basename($_FILES['userfile']['name']);

  $pdf=$_FILES['userfile']['name'];
  $error=$_FILES['userfile']['error'];
  


 $sql="INSERT INTO upload5(userfile) VALUES('$pdf')";
 mysqli_query($con,$sql) or die('sorry');

 if(move_uploaded_file($_FILES['userfile']['tmp_name'],$target)){

  $msg="file uploaded succesfully";
  echo "<script>
  alert('successfully uploaded');
        window.location.href='cse1.php';
        </script>";
}
else{
$msg="Failed to upload a file";
   echo "<script>
  alert('successfully uploaded');
        window.location.href='cse6.php';
        </script>";
}
}

?>
