<html>
<body>
<a href="home1.php">Logout</a>
</body>
</html>
