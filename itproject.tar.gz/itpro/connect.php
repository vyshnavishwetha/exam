<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "123456";
$dbname = "itpro";
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname)or die('cannot connect to the server'); 
?>
